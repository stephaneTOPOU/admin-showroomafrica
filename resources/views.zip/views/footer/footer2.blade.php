


@yield('javascripts')
</body>
</html>